package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {

    @GetMapping({"/", "/log_in"})
    public String index() {
        return "index";
    }

    @GetMapping({"/", "home"})
    public String home() {
        return "home";
    }

}
